Invoice Documents

Please review the attached files.

Regards,
Finance Team
